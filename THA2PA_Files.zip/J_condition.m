%function to find the conditional number of the Jacobian
function [conAw, conAv] = J_condition(J)

%Separate Jacobian into angular and linear portions
Jw = J(1:3,:);
Jv = J(1:3,:);
%calculate angular and linear manipulability ellipsoid
Aw = Jw * Jw';
Av = Jv * Jv';
%derive eigenvectors and eigenvalues
[Vw, Dw] = eig(Aw);
[Vv, Dv] = eig(Av);

%calculate the isotropy of the linear and angular manipulability matrices
%using max and min values of eigenvector matrices.
conAw = sqrt(Dw(1)/Dw(end));
conAv = sqrt(Dv(1)/Dv(end));

end
