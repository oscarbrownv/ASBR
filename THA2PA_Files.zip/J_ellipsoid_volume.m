%Function to compute the ellipsoid volume of the Jacobian
function [volAw, volAv] = J_ellipsoid_volume(J)

%Separate Jacobian into angular and linear portions
Jw = J(1:3,:);
Jv = J(1:3,:);
%calculate angular and linear manipulability ellipsoid
Aw = Jw * Jw';
Av = Jv * Jv';
%derive eigenvectors and eigenvalues
[Vw, Dw] = eig(Aw);
[Vv, Dv] = eig(Av);

%calculate the isotropy of the linear and angular manipulability matrices
%using max and min values of eigenvector matrices.
volAw = trace(Dw);
volAv = trace(Dv);


end
