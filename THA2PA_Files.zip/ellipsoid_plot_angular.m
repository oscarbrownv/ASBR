function ellipsoid_plot_angular(Jw)
% ellipsoid_plot_angluar.m plot the manipulability ellipsoids for the
% angular velocities.
%
% Inputs:
%   Jw: the top three rows of the Jacobian of the manipulator

%compute the manipulability matrix
A = Jw * Jw';
%find the eigenvectors and eigenvalues
[V, D] = eig(A);
%create the initial ellipsoid from the eigenvalues
[X, Y, Z] = ellipsoid(0, 0, 0, D(1,1), D(2,2), D(3,3));

%group the 3D points of the ellipsoid into one array
ellipsoid_points = [X(:) Y(:) Z(:)]';
%rotate the ellipsoid using the eigenvectors to align the ellipsoid with
%the eigenvector directions
rotated_points = V * ellipsoid_points;
%converting the list of points back into matrices for plotting
X_rot = reshape(rotated_points(1,:), size(X));
Y_rot = reshape(rotated_points(2,:), size(Y));
Z_rot = reshape(rotated_points(3,:), size(Z));


figure;
%plot the roated matrices as a surface
s = surf(X_rot, Y_rot, Z_rot);
hold on;
%make surface transparent
set(s, 'FaceAlpha', 0.5, 'EdgeColor', 'none');
%plotting eigenvectors
quiver3(0,0,0, V(1,1), V(2,1), V(3,1), 0, 'r', 'LineWidth', 4);
quiver3(0,0,0, V(1,2), V(2,2), V(3,2), 0, 'r', 'LineWidth', 4);
quiver3(0,0,0, V(1,3), V(2,3), V(3,3), 0, 'r', 'LineWidth', 4);
%plotting scaled eigenvalues
quiver3(0, 0, 0, D(1,1)*V(1,1), D(1,1)*V(2,1), D(1,1)*V(3,1), 0, 'b', 'LineWidth', 2);
quiver3(0, 0, 0, D(2,2)*V(1,2), D(2,2)*V(2,2), D(2,2)*V(3,2), 0, 'b', 'LineWidth', 2);
quiver3(0, 0, 0, D(3,3)*V(1,3), D(3,3)*V(2,3), D(3,3)*V(3,3), 0, 'b', 'LineWidth', 2);
%creating axis labels
xlabel('X');
ylabel('Y');
zlabel('Z');
%creating a title
title('Angular Manipulability Ellipsoid at Home Configuration');
axis equal
grid on;
view(3);

end