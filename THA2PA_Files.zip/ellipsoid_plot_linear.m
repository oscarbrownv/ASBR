function ellipsoid_plot_linear(Jv)
% ellipsoid_plot_linear.m plot the manipulability ellipsoids for the
% linear velocities.
%
% Inputs:
%   Jv: the bottom three rows of the Jacobian of the manipulator

%compute the manipulability matrix
A = Jv * Jv';
%find the eigenvectors and eigenvalues
[V, D] = eig(A);

%set a minimum for the eigenvalues so that they appear even when small
r_min = 1e-6;
%defining the length of the axes of the ellipsoid with a minimum threshold
%of 1e-6 for visibility
[X, Y, Z] = ellipsoid(0, 0, 0, sqrt(max(D(1,1),r_min)), sqrt(max(D(2,2),r_min)), sqrt(max(D(3,3),r_min)));

%group the 3D points of the ellipsoid into one array
ellipsoid_points = [X(:) Y(:) Z(:)]';
%rotate the ellipsoid using the eigenvectors to align the ellipsoid with
%the eigenvector direction
rotated_points = V * ellipsoid_points;
%converting the list of points back into matrices for plotting
X_rot = reshape(rotated_points(1,:), size(X));
Y_rot = reshape(rotated_points(2,:), size(Y));
Z_rot = reshape(rotated_points(3,:), size(Z));


figure;
%plot the roated matrices as a surface
s = surf(X_rot, Y_rot, Z_rot);
hold on;
set(s, 'FaceAlpha', 0.5, 'EdgeColor', 'none');
%plotting scaled eigenvectors. Scaled for visibility
quiver3(0,0,0, 100*V(1,1), 100*V(2,1), 100*V(3,1), 0, 'r', 'LineWidth', 4, 'AutoScale', 'off');
quiver3(0,0,0, 100*V(1,2), 100*V(2,2), 100*V(3,2), 0, 'r', 'LineWidth', 4, 'AutoScale', 'off');
quiver3(0,0,0, 100*V(1,3), 100*V(2,3), 100*V(3,3), 0, 'r', 'LineWidth', 4, 'AutoScale', 'off');
%plotting scaled eigenvalues
quiver3(0, 0, 0, sqrt(D(1,1))*V(1,1), sqrt(D(1,1))*V(2,1), sqrt(D(1,1))*V(3,1), 0, 'b', 'LineWidth', 2);
quiver3(0, 0, 0, sqrt(D(2,2))*V(1,2), sqrt(D(2,2))*V(2,2), sqrt(D(2,2))*V(3,2), 0, 'b', 'LineWidth', 2);
quiver3(0, 0, 0, sqrt(D(3,3))*V(1,3), sqrt(D(3,3))*V(2,3), sqrt(D(3,3))*V(3,3), 0, 'b', 'LineWidth', 2);
%creating axis labels
xlabel('X');
ylabel('Y');
zlabel('Z');
%creating a title
title('Linear Manipulability Ellipsoid at Home Configurationf');
axis equal;
grid on;
view(3);


end