function singularities = singularity(screwaxes, M, joint_limits)

%define by number of screwaxes columns
n = size(screwaxes, 2);
%create n symbolic q's
q = sym('q', [n, 1], 'real');



T = eye(4);
%Find the transformation matrices of the joints using symbolic angles
for i=1:n
    T = simplify(T * expm(screw2S_hat(screwaxes(:, i)) * q(i)));
end
%simplify where possible
T0 = simplify(T*M);

spaceJ = sym(zeros(6,n));
T_i = eye(4);
%calculate the columns of the space jacobian
for i = 1:n
    if i ==1
        spaceJ(:,1) = screwaxes(:,1);
    else
        adjointT = Adjoint(T_i);
        spaceJ(:,i) = simplify(adjointT * screwaxes(:,i));
    end

    T_i = simplify(T_i * expm(screw2S_hat(screwaxes(:, i)) * q(i)));
end
%simplify where possible
spaceJ = simplify(spaceJ);

%catch manipulators with too many degrees of freedom
if n ~= 6
    warning('The Jacobian is not square. Taking the first 6 columns for determinant computing');
    squareJ = spaceJ(:, 1:6);
else
    squareJ = spaceJ;
end

detJ = simplify(det(squareJ));
%assign joint limits of robot
for i = 1:n
    assumeAlso(q(i) >= joint_limits(i,1));
    assumeAlso(q(i) <= joint_limits(i,2));
end
%q1 and q4 have the same effect on singularity regardless of position
assumeAlso(q(1) == 0);   
assumeAlso(q(4) == 0);  
%solve the values of the symbolic joint angles when the determinant of J is
%equal to 0
singularities = solve(detJ == 0, q, 'ReturnConditions', false);
%display the singularities and conditions of singularities
fprintf('Singularity condition (det(J) = 0) is: \n');
disp(detJ);
fprintf('Singularity solutions and conditions:\n');
disp(singularities);

end
